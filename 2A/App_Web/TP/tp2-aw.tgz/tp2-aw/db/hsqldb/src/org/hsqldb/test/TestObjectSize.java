/* Copyright (c) 2001-2011, The HSQL Development Group
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 * Redistributions of source code must retain the above copyright notice, this
 * list of conditions and the following disclaimer.
 *
 * Redistributions in binary form must reproduce the above copyright notice,
 * this list of conditions and the following disclaimer in the documentation
 * and/or other materials provided with the distribution.
 *
 * Neither the name of the HSQL Development Group nor the names of its
 * contributors may be used to endorse or promote products derived from this
 * software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL HSQL DEVELOPMENT GROUP, HSQLDB.ORG,
 * OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 * LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
 * ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 * (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
 * SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */


package org.hsqldb.test;

import java.sql.Timestamp;

import org.hsqldb.lib.StopWatch;

public class TestObjectSize {

    public TestObjectSize() {

        StopWatch sw        = new StopWatch();
        int       testCount = 2350000;

        System.out.println("Fill Memory with Objects ");

        Object[] objectArray = new Object[testCount];

        for (int j = 0; j < objectArray.length; j++) {
            objectArray[j] = new Timestamp(0);
        }

        System.out.println("Array Filled " + sw.elapsedTime());

        for (int j = 0; j < objectArray.length; j++) {
            objectArray[j] = null;
        }

        Object[] objectArray2 = new Object[testCount];
        Object[] objectArray3 = new Object[testCount];
        Object[] objectArray4 = new Object[testCount];
        Object[] objectArray5 = new Object[testCount];
        Object[] objectArray6 = new Object[testCount];

//        Object[] objectArray7 = new Object[testCount];
        short[] shortArray = new short[testCount];
        byte[]  byteArray  = new byte[testCount];

        System.out.println("Fill with Empty Arrays " + sw.elapsedTime());
        sw.zero();
    }

    public static void main(String[] argv) {
        TestObjectSize ls = new TestObjectSize();
    }
}
